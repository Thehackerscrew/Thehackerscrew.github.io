# Memory Revenge

## Description

Execute `/flag`
Author: sqrtrev

## For deploy
run `docker-compose up`

## For attachment
remove `flag` and `flag.c` file for attachment.

