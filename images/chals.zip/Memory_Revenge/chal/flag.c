#include <stdio.h>

int main(void){
	printf("Bsides{PHAR_TAR_FAR!!}");
}
