from flask import Flask, request

internal = Flask(__name__)

@internal.route('/flag')
def flag():
    return 'Bsides{Do_NOT_TRUST_PYTHON}'

internal.run(host='0.0.0.0', port=31337)