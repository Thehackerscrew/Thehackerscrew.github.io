# query-master
- Author : sqrtrev

## Descriptions
:eyes:

## Flag
`Bsides{SQLITE_CLI_DOCUMENTATION}`

## Deployment Guide
`sudo ./run.sh`

## Distribution Guide
Everything in `public` directory